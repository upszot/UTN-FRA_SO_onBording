Linux Usuarios

Puede ejecutar el programa en Ubuntu system usando estos pasos:

1. Copie estos archivos en la misca carpeta que instalo Parabola.exe

2. Ejecute  Parabola.exe usando Wine

Si tiene problemas intente abriendo una consola window, vaya a la carpeta donde esta Parabola.exe 
y ejecute el comando wine Parabola.exe

Saludos.

Chalenger.
julio 2010